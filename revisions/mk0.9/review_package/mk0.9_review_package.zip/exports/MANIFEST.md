# mk0.9 export manifest

Generated from CadQuery source. STEP/STL files are derived artifacts.

## printable/plastic

- `base_module`
- `bottom_grill`
- `dust_filter_slot`
- `foot_mounts`
- `m5_threaded_rod_cap`
- `mini_pc_placeholder_module`
- `roof_module`
- `rpi_ssd_module`
- `top_filter_slot`

## printable/tpu

- `foot`

## non_printable/metal_reference

- `m5_threaded_rod`

## placeholders/devices

- `external_ssd_placeholder`
- `mini_pc_placeholder`
- `raspberry_pi_3b_placeholder`

## placeholders/fans

- `fan_120x120x25_placeholder`

## placeholders/filters

- `dust_filter_placeholder`
- `top_guard_filter_mesh_placeholder`

## review

- `airflow_clearance_zone`
- `central_airflow_channel_placeholder`
- `module_interface_bottom`
- `module_interface_top`
- `simplified_airflow_guide`
