# mk0.9.3 export manifest

Generated from CadQuery source. STEP/STL files are derived artifacts.

## printed/plastic_modules

- `base_module`
- `mini_pc_placeholder_module`
- `roof_module`
- `rpi_ssd_module`

## printed/plastic_subparts

- `bottom_grill`
- `dust_filter_slot`
- `foot_mounts`
- `m5_threaded_rod_cap`
- `mini_pc_placeholder_carriage`
- `rail_end_clip`
- `rpi_ssd_carriage`
- `top_filter_slot`

## printed/tpu

- `foot`

## reference_non_printed/metal

- `aluminum_u_channel_rail_placeholder`
- `m5_threaded_rod`

## reference_non_printed/wear_parts

- `pom_c_shoe_placeholder`
- `tpu_foot_placeholder`

## reference_placeholders/devices

- `external_ssd_placeholder`
- `mini_pc_placeholder`
- `raspberry_pi_3b_placeholder`

## reference_placeholders/fans

- `fan_120x120x25_placeholder`

## reference_placeholders/filters

- `dust_filter_placeholder`
- `top_guard_filter_mesh_placeholder`

## review

- `airflow_clearance_zone`
- `central_airflow_channel_placeholder`
- `module_interface_bottom`
- `module_interface_top`
- `simplified_airflow_guide`

## legacy_do_not_print

- `mini_pc_placeholder_airflow_guide`
- `mini_pc_placeholder_retainer`
- `mini_pc_placeholder_tray`
- `rail_end_mount`
- `rpi_mount_posts`
- `rpi_ssd_tray`
- `ssd_retainer`
- `tray_support_ledge`
